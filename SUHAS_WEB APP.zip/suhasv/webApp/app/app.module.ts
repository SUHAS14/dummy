import { AppComponent } from './app.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';

import { EmployeeTableComponent } from './employees/employee-table.component';
import { EmployeeFilterComponent } from './employees/employee-filter.pipe';
import { EmployeeInfoComponent } from './employees/employee-info.component';
import { StartComponent } from './home/start.component';
import { HeaderComponent } from './shared/header.component';
import { EmployeeService } from './employees/employee.service';
import { EmployeeAdvancedFilterComponent } from './employees/employee-advanced-filter.component';
import { LoginComponent } from './login/login.component';
import { UserService } from './login/user.service';

@NgModule({
  imports: [BrowserModule, FormsModule, HttpModule, RouterModule.forRoot([
    { path: 'start', component: StartComponent },
    { path: 'employee-table', component: EmployeeTableComponent},
    { path: 'employee-info/:id', component: EmployeeInfoComponent },
    { path: '', redirectTo: 'start', pathMatch: 'full' },
    { path: '**', redirectTo: 'start', pathMatch: 'full' }
  ])],

  declarations: [AppComponent,
    EmployeeTableComponent,
    EmployeeFilterComponent,
    StartComponent, EmployeeInfoComponent,
    HeaderComponent,
    EmployeeAdvancedFilterComponent,
    LoginComponent],

  bootstrap: [AppComponent],

  providers: [EmployeeService,UserService]
})

export class AppModule { }
