import { Component, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'bms-af',
    templateUrl: 'app/employees/employee-advanced-filter.component.html',
    styleUrls: ['app/employees/employee-advanced-filter.component.css']
})

export class EmployeeAdvancedFilterComponent {
    header: string = 'Refine';
    skills: string;
    pos: string;
    loc: string;

    @Output() refines: EventEmitter<string> = new EventEmitter<string>();

    refine(skills: string, pos: string, loc: string): void {
        var categories = skills + ',' + pos + ',' + loc;
        this.refines.emit(`${categories}`);
    }

    clear(): void {
        this.skills = this.pos = this.loc = '';        
        this.refines.emit("Clear");
    }

    change(): void {
        this.refines.emit("Clear");
    }
}