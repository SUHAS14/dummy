export interface IEmployee{
    ID:string;
    Name:string;
    DOJ:string;
    Exp:string;
    Position:string;
    Skills:string;
    DOB:string;
    Trainings:string;
    PreviousEmployer:string;
    Degree:string;
    Stream:string;
    Location:string;
    PhoneNo:string;
}