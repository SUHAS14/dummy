import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { IEmployee } from './employee';
import { EmployeeService } from './employee.service';

@Component({
    templateUrl: 'app/employees/employee-table.component.html',
    styleUrls: ['app/employees/employee-table.component.css']
})

export class EmployeeTableComponent implements OnInit {
    pageTitle: string = 'Employees On Bench';
    employees: IEmployee[];
    errorMessage: string;
    filter: string;

    constructor(private _employeeService: EmployeeService, private _router: Router) { }

    ngOnInit(): void {
        this._employeeService.getEmployees().subscribe(employees =>
            this.employees = employees, error => this.errorMessage = <any>error);
    }

    onBack(): void {
        this._router.navigate(['/start']);
    }

    advanceFilter(categories: string): void {

        if (categories !== 'Clear') {
            var criteria = categories.split(',');

            if (criteria[0] != 'undefined' && criteria[0].trim().length > 0)
                this.employees = this.employees.filter((employee: IEmployee) => employee
                    .Skills.toLocaleLowerCase().indexOf(criteria[0]) !== -1);

            if (criteria[1] != 'undefined' && criteria[1].trim().length > 0)
                this.employees = this.employees.filter((employee: IEmployee) => employee
                    .Position.toLocaleLowerCase().startsWith(criteria[1]));

            if (criteria[2] != 'undefined' && criteria[2].trim().length > 0)
                this.employees = this.employees.filter((employee: IEmployee) => employee
                    .Location.toLocaleLowerCase().indexOf(criteria[2]) !== -1);
        }
        else{
             this._employeeService.getEmployees().subscribe(employees =>
                this.employees = employees, error => this.errorMessage = <any>error);
        }
    }
}