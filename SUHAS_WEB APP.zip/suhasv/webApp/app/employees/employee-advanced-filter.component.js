"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var EmployeeAdvancedFilterComponent = (function () {
    function EmployeeAdvancedFilterComponent() {
        this.header = 'Refine';
        this.refines = new core_1.EventEmitter();
    }
    EmployeeAdvancedFilterComponent.prototype.refine = function (skills, pos, loc) {
        var categories = skills + ',' + pos + ',' + loc;
        this.refines.emit("" + categories);
    };
    EmployeeAdvancedFilterComponent.prototype.clear = function () {
        this.skills = this.pos = this.loc = '';
        this.refines.emit("Clear");
    };
    EmployeeAdvancedFilterComponent.prototype.change = function () {
        this.refines.emit("Clear");
    };
    return EmployeeAdvancedFilterComponent;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], EmployeeAdvancedFilterComponent.prototype, "refines", void 0);
EmployeeAdvancedFilterComponent = __decorate([
    core_1.Component({
        selector: 'bms-af',
        templateUrl: 'app/employees/employee-advanced-filter.component.html',
        styleUrls: ['app/employees/employee-advanced-filter.component.css']
    })
], EmployeeAdvancedFilterComponent);
exports.EmployeeAdvancedFilterComponent = EmployeeAdvancedFilterComponent;
//# sourceMappingURL=employee-advanced-filter.component.js.map