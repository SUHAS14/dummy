import{Component,OnInit} from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

import {EmployeeService} from './employee.service';
import {IEmployee} from './employee';

@Component({
    templateUrl:'app/employees/employee-info.component.html',
    styleUrls:['app/employees/employee-info.component.css']
})

export class EmployeeInfoComponent implements OnInit{
    header:string = "Profile";
    employee:IEmployee;
    errorMessage:string;

    constructor(private _route:ActivatedRoute,private _router:Router ,private _employeeService:EmployeeService){ }

    ngOnInit():void{
      let id =  this._route.snapshot.params['id'];
      this._employeeService.getEmployee(id).subscribe(employee=>this.employee = employee,
      error=>this.errorMessage=<any>error );
    }

    onBack():void{
        this._router.navigate(['/employee-table']);
    }
}