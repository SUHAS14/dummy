"use strict";
var EmployeeTableGuardComponent = (function () {
    function EmployeeTableGuardComponent() {
    }
    return EmployeeTableGuardComponent;
}());
exports.EmployeeTableGuardComponent = EmployeeTableGuardComponent;
//# sourceMappingURL=employee-table.guard.component.js.map