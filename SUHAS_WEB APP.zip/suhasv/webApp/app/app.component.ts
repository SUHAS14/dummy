import { Component } from '@angular/core';

@Component({
    selector: 'bms-app',
    template: `<div><hd-com></hd-com></div>
               <div>
                    <router-outlet></router-outlet>
               </div>`,
})
export class AppComponent { 
    header:string='TAVANT';
    footer:string='TECHNOLOGIES';
}
