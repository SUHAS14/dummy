import {Component} from '@angular/core';

@Component({
    templateUrl:'app/home/start.component.html',
    styleUrls:['app/home/start.component.css']
})

export class StartComponent{
    header:string="Tavant Talent Hub";
    welcomeDescription:string = "Please use link for finding a perfect profile >>";
}