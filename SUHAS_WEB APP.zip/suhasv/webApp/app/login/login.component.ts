import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { IUser } from './user';
import { UserService } from './user.service';

@Component({
    selector: 'bms-lg',
    templateUrl: 'app/login/login.component.html',
    styleUrls: ['app/login/login.component.css']
})

export class LoginComponent {
    header: string = "Login";
    _user: IUser;
    _success: boolean = false;
    errorMessage: string;
    username: string;
    password: string;

    constructor(private _userService: UserService, private _route: Router) { }

    login(username: string, password: string): void {
        if (username != undefined && password != undefined) {

            this._userService.getUser(username, password).
                subscribe(user => {
                    this._user = user
                    if (this._user != null) {
                        this._route.navigate(['/employee-table']);
                    }
                    else {
                        this.errorMessage = "*Invalid Login";
                    }
                });
        }
        else {
            this.errorMessage = "*Please provide username and password";
        }
    }

    clear(): void {
        this.username = this.password = this.errorMessage = '';
    }
}