import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { IUser } from './user';

@Injectable()
export class UserService{
    _url: string = 'app/data/users.json';
    _currentUser:IUser;

    constructor(private _http: Http) { }
    
    getUsers(): Observable<IUser[]> {
        return this._http.get(this._url).map((response: Response) => <IUser[]>response.json())
        .catch(this.errorHandle);
    }

    getUser(username: string, password: string): Observable<IUser> {

        var user  = this.getUsers().map((users: IUser[]) => users
            .find(user =>
                (user.Username.toLocaleLowerCase() === username.toLocaleLowerCase())
                && (user.Password === password)));

        user.subscribe(user=>this._currentUser = user);

        return user;
    }

    getCurrentUser():IUser{
        return this._currentUser ;
    }

    errorHandle(error:Response):any{
        return Observable.throw(error.json().error||'Server Error');
    }
}