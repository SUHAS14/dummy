export interface IUser{
    Username:string;
    Password:string;
    SuperPrivilege:string;
}