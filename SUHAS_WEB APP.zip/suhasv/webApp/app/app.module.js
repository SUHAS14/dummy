"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var app_component_1 = require("./app.component");
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var http_1 = require("@angular/http");
var employee_table_component_1 = require("./employees/employee-table.component");
var employee_filter_pipe_1 = require("./employees/employee-filter.pipe");
var employee_info_component_1 = require("./employees/employee-info.component");
var start_component_1 = require("./home/start.component");
var header_component_1 = require("./shared/header.component");
var employee_service_1 = require("./employees/employee.service");
var employee_advanced_filter_component_1 = require("./employees/employee-advanced-filter.component");
var login_component_1 = require("./login/login.component");
var user_service_1 = require("./login/user.service");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, router_1.RouterModule.forRoot([
                { path: 'start', component: start_component_1.StartComponent },
                { path: 'employee-table', component: employee_table_component_1.EmployeeTableComponent },
                { path: 'employee-info/:id', component: employee_info_component_1.EmployeeInfoComponent },
                { path: '', redirectTo: 'start', pathMatch: 'full' },
                { path: '**', redirectTo: 'start', pathMatch: 'full' }
            ])],
        declarations: [app_component_1.AppComponent,
            employee_table_component_1.EmployeeTableComponent,
            employee_filter_pipe_1.EmployeeFilterComponent,
            start_component_1.StartComponent, employee_info_component_1.EmployeeInfoComponent,
            header_component_1.HeaderComponent,
            employee_advanced_filter_component_1.EmployeeAdvancedFilterComponent,
            login_component_1.LoginComponent],
        bootstrap: [app_component_1.AppComponent],
        providers: [employee_service_1.EmployeeService, user_service_1.UserService]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map