import {Component} from '@angular/core';

@Component({
    selector:'hd-com',
    templateUrl:'app/shared/header.component.html',
    styleUrls:['app/shared/header.component.css']
})

export class HeaderComponent{
    header:string='TAVANT';
    footer:string='TECHNOLOGIES';
}